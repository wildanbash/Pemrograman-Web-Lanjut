

<?php $__env->startSection('title', 'Detail Mahasiswa'); ?>

<?php $__env->startSection('judul_halaman', 'Detail Data Mahasiswa'); ?>

<?php $__env->startSection('konten'); ?>
    <a href="/mahasiswa" class="btn btn-danger">Kembali</a>

    <br>
    <br>
    
    
    <h5 class="card-title"><?php echo e($mahasiswa->nama); ?></h5>
    <p class="card-text">
        <label for=""><b> NIM : </b> </label>
        <?php echo e($mahasiswa->nim); ?>

    </p>
    <p class="card-text">
        <label for=""><b> Email : </b> </label>
        <?php echo e($mahasiswa->email); ?>

    </p>
    <p class="card-text">
        <label for=""><b> Jurusan : </b> </label>
        <?php echo e($mahasiswa->jurusan); ?>

    </p>
    
<?php $__env->stopSection(); ?>









<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\laravel-crud-kedua\resources\views/detail.blade.php ENDPATH**/ ?>