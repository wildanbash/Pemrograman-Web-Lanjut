

<?php $__env->startSection('title', 'Edit Data'); ?>

<?php $__env->startSection('judul_halaman', 'Edit Data Mahasiswa'); ?>

<?php $__env->startSection('konten'); ?>
    <a href="/mahasiswa" class="btn btn-danger">Kembali</a>
    <br>
    <br>
    <form action="/mahasiswa/update/<?php echo e($mahasiswa->id); ?>" method="POST">
        <?php echo e(csrf_field()); ?>

        <input type="hidden" name="id" value="<?php echo e($mahasiswa->id); ?>">
        <div class="form-group">
            <label for="namamhs">Nama</label>
            <input type="text" class="form-control" required="required" name="namamhs" value="<?php echo e($mahasiswa->nama); ?>"> <br>
        </div>
        <div class="form-group">
            <label for="nimmhs">NIM</label>
            <input type="number" class="form-control" required="required" name="nimmhs" value="<?php echo e($mahasiswa->nim); ?>"> <br>
        </div>
        <div class="form-group">
            <label for="emailmhs">E-mail</label>
            <input type="email" class="form-control" required="required" name="emailmhs" value="<?php echo e($mahasiswa->email); ?>"> <br>
        </div>
        <div class="form-group">
            <label for="jurusanmhs">Jurusan</label>
            <input type="text" class="form-control" required="required" name="jurusanmhs" value="<?php echo e($mahasiswa->jurusan); ?>"> <br>
        </div>
        <button type="submit" name="edit" class="btn btn-primary float-right">Simpan Data</button>
    </form>
    
<?php $__env->stopSection(); ?>















<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\laravel-crud-kedua\resources\views/edit.blade.php ENDPATH**/ ?>