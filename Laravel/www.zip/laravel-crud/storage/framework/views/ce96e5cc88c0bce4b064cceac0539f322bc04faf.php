

<?php $__env->startSection('title', 'Tambah Data'); ?>

<?php $__env->startSection('judul_halaman', 'Tambah Data Mahasiswa'); ?>

<?php $__env->startSection('konten'); ?>
    <a href="/mahasiswa" class="btn btn-danger">Kembali</a>
    <br>
    <br>
    <form action="/mahasiswa/simpan" method="POST">
        <?php echo e(csrf_field()); ?>

        <div class="form-group">
            <label for="namamhs">Nama</label>
            <input type="text" class="form-control" required="required" name="namamhs"> <br>
        </div>
        <div class="form-group">
            <label for="nimmhs">NIM</label>
            <input type="number" class="form-control" required="required" name="nimmhs"> <br>
        </div>
        <div class="form-group">
            <label for="emailmhs">E-mail</label>
            <input type="email" class="form-control" required="required" name="emailmhs"> <br>
        </div>
        <div class="form-group">
            <label for="jurusanmhs">Jurusan</label>
            <input type="text" class="form-control" required="required" name="jurusanmhs"> <br>
        </div>
        <button type="submit" name="tambah" class="btn btn-primary float-right">Tambah Data</button>
    </form>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\laravel-crud\resources\views/tambah.blade.php ENDPATH**/ ?>