

<?php $__env->startSection('title', 'Home'); ?>

<?php $__env->startSection('judul_halaman', 'Data Mahasiswa'); ?>

<?php $__env->startSection('konten'); ?>
    <a href="/mahasiswa/tambah" class="btn btn-primary">Tambah Data Mahasiswa</a>
    <br>
    <br>
    <table class="table table-bordered table-hover table-striped">
        <thead>
            <tr>
                <th>Nama</th>
                <th>NIM</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $mahasiswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mhs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($mhs->nama); ?></td>
                    <td><?php echo e($mhs->nim); ?></td>
                    <td>
                        <a href="/mahasiswa/detail/<?php echo e($mhs->id); ?>" class="badge badge-info">Detail</a>
                        <a href="/mahasiswa/edit/<?php echo e($mhs->id); ?>" class="badge badge-warning">Edit</a>
                        <a href="/mahasiswa/hapus/<?php echo e($mhs->id); ?>" class="badge badge-danger">Hapus</a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>





<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\laravel-crud\resources\views/index.blade.php ENDPATH**/ ?>